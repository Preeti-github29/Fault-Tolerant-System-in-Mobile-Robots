import imp
import math
from matplotlib.cbook import print_cycles
from matplotlib.pyplot import step
import rps.robotarium as robotarium
from rps.utilities.graph import *
from rps.utilities.transformations import *
from rps.utilities.barrier_certificates import *
from rps.utilities.misc import *
from rps.utilities.controllers import *

import numpy as np
# Instantiate Robotarium object
N = 4
kd = 55
#step_size = 1    # coded by me -- Preeti
r = robotarium.Robotarium(number_of_robots=N, show_figure=True, sim_in_real_time=True)

# How many iterations do we want (about N*0.033 seconds)
iterations = 650

#Maximum linear speed of robot specified by motors
magnitude_limit = 0.15

# We're working in single-integrator dynamics, and we don't want the robots
# to collide or drive off the testbed.  Thus, we're going to use barrier certificates
si_barrier_cert = create_single_integrator_barrier_certificate_with_boundary()

# Create SI to UNI dynamics tranformation
si_to_uni_dyn, uni_to_si_states = create_si_to_uni_mapping()

# Generated a connected graph Laplacian (for a cylce graph).


L = completeGL(N)
fault = np.array([[0,0],[0,0],[0,0],[0,0]])

detect_fault = -1
x = r.get_poses()
colors = [1,0,0]    
CM = np.array(colors)
robot_marker_size_m = 0.1
marker_size = determine_marker_size(r,robot_marker_size_m) # Will scale the plotted markers to be the diameter of provided argument (in meters)
font_height_meters = 0.1
font_height_points = determine_font_size(r,font_height_meters) # Will scale the plotted font height to that of the provided argument (in meters)
g = r.axes.scatter(x[0,0], x[1,0], s=np.pi/4*marker_size, marker='o', facecolors='none',edgecolors=CM,linewidth=1)
r.step()


 # Initialize the single-integrator control inputs
si_velocities = np.zeros((2, N))
x_si_expected = np.zeros((2,N))
x_prev_state = np.zeros((2,N))
error_prev = np.zeros((2,N))
temp_vel = np.zeros((2,N))
dxi = np.zeros((2, N))



for k in range(iterations):
    error = np.zeros((2,N))
    
    # Get the poses of the robots and convert to single-integrator poses
    x = r.get_poses()
    x_si = uni_to_si_states(x)
    
     
    for i in range(N):
      
        # Get the neighbors of robot 'i' (encoded in the graph Laplacian)
        j = topological_neighbors(L, i)
        # Compute the consensus algorithm
        
        si_velocities[:,i] = np.sum(x_si[:, j] - x_si[:, i, None], 1) 
        
        if (k > kd):
     
            si_velocities[:, i] = si_velocities[:, i] + fault[i]
            g.set_offsets(x[:2,0].T)
            # This updates the marker sizes if the figure window size is changed. 
            g.set_sizes([determine_marker_size(r,robot_marker_size_m)])  
            
       
        #error[:,i] = np.absolute(x_si[:,i] - x_si_expected[:,i]) 
        error[:,i] = np.abs(error_prev[:,i] - np.absolute(np.abs(x_si[:,i]-x_prev_state[:,i]) - np.abs(x_si_expected[:,i])))
        
        x_si_expected[:,i] = si_velocities[:,i]
       
         
    for i in range(N):
        if (i != detect_fault):
            if(k > kd+2):
                jj=j
                indices = np.where(jj==detect_fault)
                jj = np.delete(jj,indices)
                print(jj)
                si_velocities[:,i] = np.sum(x_si[:, jj] - x_si[:, i, None], 1) 
    
    faulty = np.transpose(error)
    if (k == (kd+2)):
        faulty_robot = np.sum(faulty,axis=1)
        detect_fault = int(np.argmax(faulty_robot))      
        print("Faulty robot is " , detect_fault +1)
    print(k)
    print(detect_fault)
    
    

    #Keep single integrator control vectors under specified magnitude
    # Threshold control inputs
    norms = np.linalg.norm(dxi, 2, 0)
    idxs_to_normalize = (norms > magnitude_limit)
    dxi[:, idxs_to_normalize] *= magnitude_limit/norms[idxs_to_normalize]

    # Use the barrier certificate to avoid collisions
    #si_velocities = si_barrier_cert(si_velocities, x_si)
    print (k)
    # Transform single integrator to unicycle
    dxu = si_to_uni_dyn(si_velocities, x)
   
    # Set the velocities of agents 1,...,N
    r.set_velocities(np.arange(N), dxu)
    error_prev = error
    x_prev_state = x_si

    # Iterate the simulation
    r.step()

#Call at end of script to print debug information and for your script to run on the Robotarium server properly
r.call_at_scripts_end()
